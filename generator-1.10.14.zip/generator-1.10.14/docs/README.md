## Documentation

Read the docs on https://www.asyncapi.com/docs/tools/generator. You can still read the docs from here, but some of the links may be broken.